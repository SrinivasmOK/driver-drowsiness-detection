import cv2
import mediapipe as mp
import numpy as np
import pygame
import time

# Initialize MediaPipe and Pygame
mp_face_mesh = mp.solutions.face_mesh
face_mesh = mp_face_mesh.FaceMesh(refine_landmarks=True, max_num_faces=5)
mp_drawing = mp.solutions.drawing_utils

pygame.mixer.init()
yawn_sound = pygame.mixer.Sound("yawn_alert.mp3")
sleep_sound = pygame.mixer.Sound("sleep_alert.mp3")

yawn_sound.set_volume(1.0)  # max = 1.0
sleep_sound.set_volume(1.0)


# Eye landmark indices
LEFT_EYE = [33, 160, 158, 133, 153, 144]
RIGHT_EYE = [263, 387, 385, 362, 380, 373]

def calculate_ear(eye_landmarks):
    # vertical distances
    A = np.linalg.norm(eye_landmarks[1] - eye_landmarks[5])
    B = np.linalg.norm(eye_landmarks[2] - eye_landmarks[4])
    # horizontal distance
    C = np.linalg.norm(eye_landmarks[0] - eye_landmarks[3])
    ear = (A + B) / (2.0 * C)
    return ear

cap = cv2.VideoCapture(0)

sleep_threshold = 0.25
sleep_frame_limit = 20
sleep_frame_counter = [0] * 5  # for 5 faces

while True:
    ret, frame = cap.read()
    if not ret:
        break

    frame = cv2.flip(frame, 1)
    h, w, _ = frame.shape
    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    results = face_mesh.process(rgb_frame)

    if results.multi_face_landmarks:
        for face_id, landmarks in enumerate(results.multi_face_landmarks):
            coords = np.array([(int(pt.x * w), int(pt.y * h)) for pt in landmarks.landmark])

            left_eye = coords[LEFT_EYE]
            right_eye = coords[RIGHT_EYE]

            left_ear = calculate_ear(left_eye)
            right_ear = calculate_ear(right_eye)
            avg_ear = (left_ear + right_ear) / 2.0

            if avg_ear < sleep_threshold:
                sleep_frame_counter[face_id] += 1
                if sleep_frame_counter[face_id] > sleep_frame_limit:
                    cv2.putText(frame, f"DROWSINESS ALERT! (Face {face_id + 1})", (10, 40 + face_id * 30),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
                    sleep_sound.play()
            else:
                sleep_frame_counter[face_id] = 0

            # Yawning detection using mouth aspect ratio (approx check)
            top_lip = coords[13]
            bottom_lip = coords[14]
            mouth_distance = np.linalg.norm(top_lip - bottom_lip)
            if mouth_distance > 30:  # tune this threshold if needed
                cv2.putText(frame, f"YAWNING DETECTED! (Face {face_id + 1})", (10, 200 + face_id * 30),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 0, 0), 2)
                yawn_sound.play()

            # Draw face mesh
            mp_drawing.draw_landmarks(
                frame,
                landmarks,
                mp_face_mesh.FACEMESH_TESSELATION,
                mp_drawing.DrawingSpec(color=(0, 255, 0), thickness=1, circle_radius=1)
            )

    cv2.imshow("Driver Drowsiness Detection", frame)
    if cv2.waitKey(1) & 0xFF == 27:
        break

cap.release()
cv2.destroyAllWindows()



